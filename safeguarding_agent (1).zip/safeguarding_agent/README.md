# Safeguarding research agent (prototype, v0.2)

Finds public pages about digital safeguarding from a defined list of sources, reads them
locally, records the evidence, scores each page, and summarises the topics they cover. It
is read-only: it never publishes or changes any website.

It supports content research for DISC. Mentions in the collected pages are not search
demand, and the priority score orders research. It is not a Google ranking score.

## Local processing and data handling

- All reading and scoring runs on this machine. Page content is not sent to any AI service.
- Network traffic is limited to the GOV.UK Search/Content APIs and page downloads from the
  configured sources. There is no open web search in this version.
- Downloaded pages are kept in `agent_data/pages/` and reused for 7 days between runs.
- robots.txt is respected for page downloads. Requests are spaced per host. Downloads use a
  fixed maximum of 5 concurrent workers.
- Because collection is limited to named sources, abusive material and case information are
  not collected. Only professional guidance and research pages are read.

## Install (Python 3.10 or newer)

    python3 -m venv .venv
    source .venv/bin/activate            # Windows: .venv\Scripts\activate
    pip install -r requirements.txt

Before the first run, put a real contact email in `user_agent` in `config.yaml`.

## Run

    python run_agent.py --sites 20

| Option | Meaning |
|---|---|
| `--sites N` | limit on pages read (default 20) |
| `--workers N` | concurrent downloads (default 3, maximum 5) |
| `--groups 1,3,6` | use only these keyword-bank groups |
| `--max-terms N` | bank terms searched per run (default 12, chosen by priority, spread across groups) |
| `--expand audiences\|platforms\|jurisdictions` | add a capped set of query variants (`expansions.max_queries`) |
| `--sources govuk,ofcom` | restrict to these source ids |
| `--format csv\|xlsx` | output format (default csv) |
| `--data-dir DIR` | where pages, logs and results go (default `./agent_data`) |

## Settings used (all in `config.yaml` and `keyword_bank.csv`)

- Sources: GOV.UK Search API filtered to Department for Education, plus the curated list in
  `sources/ofcom_urls.csv`. NSPCC and UK Safer Internet Centre are present but disabled.
- Keyword bank: 111 terms in 8 groups from Kane's brief, each with phrase, group, audience,
  jurisdiction, research/service/question intent and priority. Service phrases (group 7)
  are never searched or mixed into topic results.
- Authority tiers, score weights, thresholds, spelling variants and jurisdiction rules.

## Outputs (`agent_data/output/`)

- `page_evidence`: one row per page: publisher, dates (published, updated, retrieved; "unknown"
  when missing), jurisdiction and evidence, guidance version, withdrawal flag, evidence type
  (original or repeated/syndicated), separate relevance, authority and recency scores each
  with reasons, topics matched, inclusion decision and the query that found it
- `topic_summary`: bank topics (research and question intent only) with total mentions,
  pages, unique publishers, latest mention, authority evidence, priority score
- `keyword_candidates_for_review`: phrases found in the pages that are not in the bank,
  flagged when supported by an authoritative primary source or 2+ independent publishers.
  Nothing is added automatically. Add accepted phrases to `keyword_bank.csv` yourself
- `content_opportunities`: top topics with audience, jurisdictions, supporting sources
- `service_search_terms`: group 7 phrases kept apart, with `disc_offer_check` against
  `disc_offerings.csv` (fill it in so phrases are only linked to services DISC offers)
- `run_info`: settings, sources status, queries used

Logs are in `agent_data/logs/`. A `report_*.txt` is written whenever a run fails, is
interrupted or logs warnings. Results from interrupted runs are still saved.

## How the rules work

- Relevance (0 to 1): distinct bank terms matched, density per 1000 words, title match.
- Authority (0 to 1): publisher tier (halved if outside the publisher's remit), sourcing
  (reference section or links to guidance and authority sources), named publisher or author,
  visible date, and not being a repeat. Writing confidence is not scored.
- Recency: flags material from the last 90 days. It is not a filter. Older dated guidance
  scores no lower than 0.2 and stays in. Missing dates stay "unknown".
- Original vs repeated: pages whose text is 80% or more contained in an earlier-published
  page are marked repeated and excluded from counts and publisher independence.
- Included if relevance and authority pass their minimums and the page is not repeated or
  withdrawn.

## Tests

    pip install -r requirements-dev.txt
    python -m pytest

Covers irrelevant matches, duplicates, missing dates, failed downloads, no-candidate runs,
spelling merges, term selection caps, jurisdiction detection and GOV.UK response parsing.

## Known limitations and testing status

- Not yet run live against GOV.UK or Ofcom. The GOV.UK parser follows the published API
  format but the API is unsupported, so the first live run is the real check.
- `sources/ofcom_urls.csv` URLs are unverified and `reuse_checked` is "no" until Ofcom's
  access and reuse conditions are confirmed.
- Tested on Linux only. Mac (Sequoia 15.7.4+) and Windows 11 testing is still to do.
- Keyword matching is rule-based (sentence-level word matching), so some phrases,
  especially the question-style ones, use a shorter topical core in the `variants` column.
- Jurisdiction and version are detected from text rules and shown with their evidence. Check
  them before relying on them.
- Candidate phrases will include some generic wording. Use `keywords.ignore_phrases`.
- Writing-style assessment, detailed expertise detection and automatic reruns are deferred.
