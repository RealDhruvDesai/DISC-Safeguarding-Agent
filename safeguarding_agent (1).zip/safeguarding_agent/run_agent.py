import sys

from safeguarding_agent.cli import main

if __name__ == "__main__":
    sys.exit(main())
