"""Reads one downloaded page: text, dates, jurisdiction, version, references, term matches."""
from __future__ import annotations

import re
import zlib
from collections import Counter
from dataclasses import dataclass, field
from datetime import date
from urllib.parse import urljoin, urlparse

import trafilatura
from bs4 import BeautifulSoup
from htmldate import find_date

from .bank import WORD
from .fetch import to_date

SECOND_LEVEL = {"co.uk", "org.uk", "gov.uk", "ac.uk", "nhs.uk", "police.uk", "com.au", "gov.au", "org.au"}
WITHDRAWN = re.compile(
    r"(withdrawn|archived)\s+(on|from)|has been (withdrawn|archived|replaced)|no longer (current|valid)|"
    r"this (guidance|publication|page) (is|has been) (withdrawn|superseded)|superseded by", re.I)
REF_HEADING = re.compile(r"^\s*(references|sources|bibliography|further reading|further information|footnotes|evidence)\b", re.I)


def registered_domain(host: str) -> str:
    host = host.lower().split(":")[0]
    host = host[4:] if host.startswith("www.") else host
    if re.fullmatch(r"[\d.]+", host) or host == "localhost":
        return host
    p = host.split(".")
    return ".".join(p[-3:]) if len(p) >= 3 and ".".join(p[-2:]) in SECOND_LEVEL else ".".join(p[-2:])


def host_matches(host: str, domains) -> bool:
    host = host.lower().split(":")[0]
    return any(host == d or host.endswith("." + d) for d in domains)


@dataclass
class Page:
    url: str
    source: str = ""
    source_type: str = ""
    publisher: str = ""
    publisher_tier: str = "unlisted"
    title: str = ""
    author: str = ""
    document_type: str = ""
    reuse_checked: str = ""
    found_via: dict = field(default_factory=dict)
    words: int = 0
    published: date | None = None
    updated: date | None = None
    retrieved: date | None = None
    date_source: str = "none"
    jurisdictions: list = field(default_factory=list)
    jurisdiction: str = ""
    jurisdiction_evidence: str = ""
    guidance_version: str = "unknown"
    version_evidence: str = ""
    currency_flag: str = ""
    external_refs: int = 0
    authority_refs: int = 0
    internal_refs: int = 0
    has_reference_section: bool = False
    term_hits: Counter = field(default_factory=Counter, repr=False)
    title_hits: Counter = field(default_factory=Counter, repr=False)
    groups: set = field(default_factory=set)
    ngrams: Counter = field(default_factory=Counter, repr=False)
    rel_ngrams: Counter = field(default_factory=Counter, repr=False)
    shingles: set = field(default_factory=set, repr=False)
    relevance: float = 0.0
    relevance_evidence: str = ""
    evidence_type: str = "original"
    duplicate_of: str = ""
    authority: float = 0.0
    authority_evidence: str = ""
    recency_score: float | None = None
    recent_flag: str = "unknown"
    recency_evidence: str = ""
    included: bool = False
    reason: str = ""


def shingle_set(text: str, k: int = 5) -> set:
    t = WORD.findall(text.lower())
    return {zlib.crc32(" ".join(t[i:i + k]).encode()) for i in range(max(0, len(t) - k + 1))}


def detect_jurisdiction(title: str, text: str, rules: dict, hint: str | None):
    blob = f"{title} {text}".lower()
    counts, ev = {}, {}
    for j, pats in rules.items():
        found = {p: len(re.findall(r"\b" + re.escape(p.lower()) + r"\b", blob)) for p in pats}
        found = {p: n for p, n in found.items() if n}
        if found:
            counts[j] = sum(found.values())
            ev[j] = ", ".join(f"{p} x{n}" for p, n in sorted(found.items(), key=lambda x: -x[1])[:3])
    if not counts:
        if hint:
            return [hint], f"{hint} (source default, not confirmed in text)"
        return [], "unclear (no jurisdiction terms found)"
    top = max(counts.values())
    chosen = [j for j, c in counts.items() if c >= max(2, 0.4 * top)] or [max(counts, key=counts.get)]
    return chosen, " | ".join(f"{j}: {ev[j]}" for j in chosen)


def detect_version(title: str, text: str):
    parts, ev = [], []
    m = re.search(r"\bversion\s*(\d+(?:\.\d+)*)", text[:3000], re.I)
    y = re.search(r"\b(20\d{2})\b", title)
    if y:
        parts.append(y.group(1))
        ev.append("year in title")
    if m:
        parts.append(f"v{m.group(1)}")
        ev.append("version number in text")
    return (" ".join(parts) or "unknown"), ("; ".join(ev) or "no version or year found")


def resolve_publisher(cand, api: dict, cfg: dict) -> str:
    names = cfg.get("govuk_org_publishers", {})
    for org in (api.get("organisations") or cand.api.get("organisations") or []):
        name = names.get(org.get("slug", "")) or org.get("title", "")
        if name:
            return name
    return cand.publisher or "unknown"


def analyse_page(cand, html: str, meta: dict, api: dict, matcher, cfg: dict) -> Page:
    """Raises ValueError when the page has too little readable text."""
    text = trafilatura.extract(html, url=cand.url, include_comments=False, include_tables=True)
    words = len(WORD.findall((text or "").lower()))
    if not text or words < cfg["fetch"]["min_words"]:
        raise ValueError(f"too little text ({words} words)")
    md = trafilatura.extract_metadata(html, default_url=cand.url)
    p = Page(url=cand.url, source=cand.source_id, source_type=cand.source_type, words=words,
             reuse_checked=cand.reuse_checked, found_via=cand.found_via)
    title = (getattr(md, "title", "") or cand.api.get("title", "") or "").strip()
    p.title = re.sub(r"\s+[-|]\s+(GOV\.UK|Ofcom)\s*$", "", title, flags=re.I)
    p.author = (getattr(md, "author", "") or "").strip()
    p.document_type = api.get("document_type") or cand.api.get("format") or "web page"

    p.publisher = resolve_publisher(cand, api, cfg)
    info = cfg["publishers"].get(p.publisher)
    p.publisher_tier = info["tier"] if info else ("other_government" if cand.source_type == "govuk_search_api" else "unlisted")

    # dates: published, updated and retrieved are kept separate. Missing stays missing.
    today = date.today()
    src = []
    p.published, p.updated = api.get("published"), api.get("updated")
    if p.published or p.updated:
        src.append("GOV.UK content API")
    elif cand.api.get("public_timestamp"):
        p.updated = to_date(cand.api["public_timestamp"])
        src.append("GOV.UK search API (updated only)")
    if not (p.published or p.updated):
        kw = dict(url=cand.url, extensive_search=False, outputformat="%Y-%m-%d", max_date=today.isoformat())
        try:
            p.published = to_date(find_date(html, original_date=True, **kw))
            p.updated = to_date(find_date(html, original_date=False, **kw))
            if p.published or p.updated:
                src.append("page markup")
        except Exception:
            pass
    p.date_source = "; ".join(src) or "none found"
    p.retrieved = to_date((meta.get("fetched_at") or "")[:10]) or today

    p.jurisdictions, p.jurisdiction_evidence = detect_jurisdiction(
        p.title, text, cfg["jurisdiction_rules"], (info or {}).get("jurisdiction_hint"))
    p.jurisdiction = "; ".join(p.jurisdictions) or "unclear"
    p.guidance_version, p.version_evidence = detect_version(p.title, text)
    if api.get("withdrawn"):
        p.currency_flag = "withdrawn (GOV.UK content API)"
    elif WITHDRAWN.search(text[:2500]):
        p.currency_flag = "possibly withdrawn or superseded (page text)"
    else:
        p.currency_flag = "no withdrawal flag found"

    # references
    soup = BeautifulSoup(html, "lxml")
    for tag in soup(["nav", "footer", "header", "aside", "script", "style"]):
        tag.decompose()
    scope = soup.find("main") or soup
    dom, self_path = registered_domain(urlparse(cand.url).netloc), urlparse(cand.url).path.rstrip("/")
    ext, internal = set(), set()
    for a in scope.find_all("a", href=True):
        h = urlparse(urljoin(cand.url, a["href"]))
        if h.scheme not in ("http", "https"):
            continue
        if registered_domain(h.netloc) != dom:
            ext.add(h.netloc.lower())
        elif h.path.rstrip("/") != self_path and any(h.path.startswith(x) for x in cfg["internal_reference_prefixes"]):
            internal.add(h.path.rstrip("/"))
    p.external_refs, p.internal_refs = len(ext), len(internal)
    p.authority_refs = sum(1 for h in ext if host_matches(h, cfg["authority_domains"]))
    p.has_reference_section = any(REF_HEADING.match(h.get_text(" ", strip=True)) for h in scope.find_all(["h2", "h3", "h4"]))

    # term matching (whole bank), plus phrases for keyword discovery
    p.term_hits, ngrams, rel = matcher.scan(text)
    p.title_hits = matcher.hits(f"{p.title}. {getattr(md, 'description', '') or ''}")
    p.groups = {matcher.by_id[t].group for t in p.term_hits if matcher.by_id[t].intent != "service"}
    keep = {g for g, c in ngrams.items() if c >= cfg["keywords"]["min_term_count"]}
    p.ngrams = Counter({g: ngrams[g] for g in keep})
    p.rel_ngrams = Counter({g: rel[g] for g in keep})
    p.shingles = shingle_set(text)
    return p
