import argparse
import sys

from .pipeline import MAX_CONCURRENCY, Options, execute


def main(argv=None) -> int:
    d = Options()
    ap = argparse.ArgumentParser(description="Safeguarding research agent (prototype). Local and read-only.")
    ap.add_argument("--sites", type=int, default=d.sites, help="limit on pages read (default %(default)s)")
    ap.add_argument("--workers", type=int, default=d.workers, help=f"concurrent downloads (default %(default)s, maximum {MAX_CONCURRENCY})")
    ap.add_argument("--groups", help="keyword bank groups to use, e.g. 1,3,6 (default: all research groups)")
    ap.add_argument("--max-terms", type=int, default=d.max_terms, help="bank terms searched per run (default %(default)s)")
    ap.add_argument("--expand", choices=["audiences", "platforms", "jurisdictions"], default="", help="add a capped set of query variants")
    ap.add_argument("--sources", help="comma-separated source ids to use (default: all enabled in config.yaml)")
    ap.add_argument("--format", choices=["csv", "xlsx"], default=d.fmt)
    ap.add_argument("--data-dir", default=d.data_dir, help="where pages, logs and results are kept")
    ap.add_argument("--config", default=d.config)
    a = ap.parse_args(argv)
    for stream in (sys.stdout, sys.stderr):  # Windows consoles often cannot print every character in a page title
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(errors="replace")
    return execute(Options(sites=a.sites, workers=a.workers, max_terms=a.max_terms, expand=a.expand, fmt=a.format,
                           groups=[int(x) for x in a.groups.split(",")] if a.groups else None,
                           sources=a.sources.split(",") if a.sources else None, data_dir=a.data_dir, config=a.config))
