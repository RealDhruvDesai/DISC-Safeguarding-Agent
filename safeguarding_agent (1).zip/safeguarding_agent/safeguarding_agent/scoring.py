"""Relevance, authority and recency are scored separately, each with its evidence."""
from __future__ import annotations

from datetime import date


def best_date(p):
    ds = [d for d in (p.published, p.updated) if d]
    return max(ds) if ds else None


def score_relevance(p, by_id: dict, cfg: dict):
    rc = cfg["relevance"]
    hits = {tid: n for tid, n in p.term_hits.items() if by_id[tid].intent != "service"}
    title = {tid for tid in p.title_hits if by_id[tid].intent != "service"}
    density = sum(hits.values()) / max(p.words, 1) * 1000
    score = (0.5 * min(1, len(hits) / rc["distinct_terms_for_full_score"])
             + 0.3 * min(1, density / rc["mentions_per_1000_words_for_full_score"])
             + (rc["title_match_bonus"] if title else 0))
    p.relevance = round(min(1.0, score), 2)
    top = sorted(hits.items(), key=lambda x: -x[1])[:3]
    p.relevance_evidence = (
        f"{len(hits)} bank terms matched; top: " + (", ".join(f"{by_id[t].phrase} x{n}" for t, n in top) or "none")
        + f"; {density:.1f} mentions per 1000 words; title/description match: {'yes' if title else 'no'}")


def mark_duplicates(pages: list, cfg: dict):
    """Flag near-copies. The earliest-published (then highest-tier) page is the original."""
    dc, tiers = cfg["duplicates"], cfg["tiers"]

    def order(p):
        d = p.published or p.updated  # earliest publication date marks the original, not the latest edit
        return (d or date.max, -tiers.get(p.publisher_tier, 0))

    ranked = sorted(pages, key=order)
    originals = []
    for p in ranked:
        p.evidence_type, p.duplicate_of = "original", ""
        for o in originals:
            small = min(len(p.shingles), len(o.shingles))
            if small >= dc["min_shingles"] and len(p.shingles & o.shingles) / small >= dc["containment_threshold"]:
                p.evidence_type, p.duplicate_of = "repeated/syndicated", o.url
                break
        if p.evidence_type == "original":
            originals.append(p)


def score_authority(p, cfg: dict):
    """Expertise and sourcing, not domain familiarity or writing confidence."""
    w, notes = cfg["authority_weights"], []
    credit = cfg["tiers"].get(p.publisher_tier, 0.0)
    remit = (cfg["publishers"].get(p.publisher) or {}).get("remit_groups")
    note = f"publisher {p.publisher} ({p.publisher_tier}) +{credit:.2f}"
    if remit is not None and not (p.groups & set(remit)):
        credit *= 0.5
        note = f"publisher {p.publisher} ({p.publisher_tier}), outside usual remit, halved +{credit:.2f}"
    notes.append(note)
    refs = p.authority_refs + p.internal_refs
    if p.has_reference_section or refs >= 5:
        s = w["sourcing"]
    elif refs >= 1 or p.external_refs >= 3:
        s = w["sourcing"] / 2
    else:
        s = 0.0
    notes.append(f"sourcing +{s:.2f} ({p.authority_refs} authority links, {p.internal_refs} guidance links, "
                 f"{p.external_refs} external domains, reference section: {'yes' if p.has_reference_section else 'no'})")
    named = w["named_publisher_or_author"] if (p.author or p.publisher_tier != "unlisted") else 0.0
    notes.append(f"named publisher/author +{named:.2f}")
    dated = w["dated"] if (p.published or p.updated) else 0.0
    notes.append(f"dated +{dated:.2f}")
    orig = w["original"] if p.evidence_type == "original" else 0.0
    notes.append(f"original +{orig:.2f}" if orig else f"repeat of {p.duplicate_of} +0.00")
    p.authority = round(min(1.0, credit + s + named + dated + orig), 2)
    p.authority_evidence = "; ".join(notes)


def score_recency(p, cfg: dict, today: date):
    rc, d = cfg["recency"], best_date(p)
    if not d:
        p.recency_score, p.recent_flag = None, "unknown"
        p.recency_evidence = "no published or updated date found"
        return
    age = (today - d).days
    p.recent_flag = "yes" if age <= rc["recent_days"] else "no"
    if p.recent_flag == "yes":
        p.recency_score = 1.0
    else:
        frac = min(1.0, (age - rc["recent_days"]) / max(rc["decay_days"] - rc["recent_days"], 1))
        p.recency_score = round(1.0 - frac * (1.0 - rc["floor"]), 2)
    which = "updated" if p.updated == d else "published"
    p.recency_evidence = f"{which} {d.isoformat()} ({age} days ago)"


def decide_inclusion(p, cfg: dict):
    reasons = []
    if p.evidence_type != "original":
        reasons.append(f"repeated/syndicated, original is {p.duplicate_of}")
    if p.relevance < cfg["relevance"]["min_relevance"]:
        reasons.append("relevance below minimum")
    if p.authority < cfg["authority_weights"]["min_authority"]:
        reasons.append("authority below minimum")
    if p.currency_flag.startswith(("withdrawn", "possibly")) and not cfg["include_withdrawn"]:
        reasons.append(p.currency_flag)
    p.included = not reasons
    p.reason = "included" if p.included else "; ".join(reasons)


def finalise(pages: list, cfg: dict, today: date | None = None):
    today = today or date.today()
    mark_duplicates(pages, cfg)
    for p in pages:
        score_authority(p, cfg)
        score_recency(p, cfg, today)
        decide_inclusion(p, cfg)
