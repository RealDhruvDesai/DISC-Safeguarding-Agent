"""Safeguarding research agent (prototype). Local, read-only."""
__version__ = "0.2.0"
