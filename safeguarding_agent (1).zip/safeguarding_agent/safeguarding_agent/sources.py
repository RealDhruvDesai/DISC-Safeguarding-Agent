"""Where candidate pages come from: GOV.UK Search API and curated URL lists."""
from __future__ import annotations

import csv
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

import requests

log = logging.getLogger("agent")


@dataclass
class Candidate:
    url: str
    source_id: str
    source_type: str
    publisher: str = ""
    found_via: dict = field(default_factory=dict)
    api: dict = field(default_factory=dict)
    reuse_checked: str = ""


def normalise_url(u: str) -> str:
    p = urlparse(u.strip())
    host = p.netloc.lower()
    host = host[4:] if host.startswith("www.") else host
    q = urlencode([(k, v) for k, v in parse_qsl(p.query) if not k.lower().startswith("utm_")])
    return urlunparse((p.scheme.lower(), host, p.path.rstrip("/") or "/", "", q, ""))


def parse_govuk_results(data: dict, base: str, exclude_formats=()) -> list:
    """Defensive parser for GOV.UK Search API JSON (the API is unsupported and may change)."""
    out = []
    for r in (data or {}).get("results", []) or []:
        link = r.get("link") or ""
        if not link:
            continue
        url = link if link.startswith("http") else base.rstrip("/") + link
        if not urlparse(url).netloc.endswith("gov.uk"):
            continue
        fmt = r.get("format") or r.get("content_store_document_type") or ""
        if fmt in exclude_formats:
            continue
        orgs = [{"slug": o.get("slug", ""), "title": o.get("title", "")}
                for o in (r.get("organisations") or []) if isinstance(o, dict)]
        out.append({"url": url, "title": r.get("title", ""), "description": r.get("description", ""),
                    "format": fmt, "public_timestamp": r.get("public_timestamp", ""), "organisations": orgs})
    return out


def govuk_search(query: str, src: dict, headers: dict, timeout: int) -> list:
    params = {"q": query, "count": src["results_per_query"]}
    if src.get("organisations"):
        params["filter_organisations"] = src["organisations"]
    r = requests.get(src["base_url"].rstrip("/") + "/api/search.json", params=params, headers=headers, timeout=timeout)
    r.raise_for_status()
    return parse_govuk_results(r.json(), src["base_url"], src.get("exclude_formats", []))


def load_url_list(src: dict, root: Path) -> list:
    path = Path(src["file"])
    path = path if path.is_absolute() else root / path
    out = []
    with open(path, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            url = (row.get("url") or "").strip()
            if not url or url.startswith("#"):
                continue
            out.append(Candidate(url=url, source_id=src["id"], source_type="url_list",
                                 publisher=(row.get("publisher") or src.get("publisher") or "").strip(),
                                 found_via={"phrase": "curated list", "group": "", "audience": "", "jurisdiction": "", "intent": ""},
                                 reuse_checked=(row.get("reuse_checked") or "unknown").strip()))
    return out


def collect_candidates(cfg: dict, queries: list, only_sources, limit: int, root: Path, status: list) -> list:
    """Curated lists first, then API results interleaved across queries so one term cannot dominate."""
    headers, timeout = {"User-Agent": cfg["user_agent"]}, cfg["fetch"]["timeout_seconds"]
    curated, api_lists = [], []
    unknown = set(only_sources or []) - {s["id"] for s in cfg["sources"]}
    if unknown:
        log.warning("--sources named unknown source id(s): %s", ", ".join(sorted(unknown)))
    for src in cfg["sources"]:
        if not src.get("enabled") or (only_sources and src["id"] not in only_sources):
            continue
        try:
            if src["type"] == "url_list":
                items = load_url_list(src, root)
                unchecked = sum(1 for c in items if c.reuse_checked.lower() != "yes")
                if unchecked:
                    log.warning("%s: %d URL(s) not marked reuse_checked=yes. Check access and reuse conditions", src["id"], unchecked)
                curated += items
                status.append({"source": src["id"], "status": f"ok, {len(items)} URLs listed ({unchecked} reuse not confirmed)"})
            elif src["type"] == "govuk_search_api":
                fails, got = 0, 0
                for q in queries:
                    try:
                        res = govuk_search(q.text, src, headers, timeout)
                        fails = 0
                    except Exception as e:
                        fails += 1
                        log.warning("GOV.UK search failed for %r: %s", q.text, e)
                        if fails >= 3:
                            raise RuntimeError("GOV.UK Search API failed 3 queries in a row") from e
                        continue
                    time.sleep(src["delay_seconds"])
                    via = {"phrase": q.text, "group": q.term.group_name, "audience": q.audience,
                           "jurisdiction": q.jurisdiction, "intent": q.term.intent}
                    api_lists.append([Candidate(url=r["url"], source_id=src["id"], source_type="govuk_search_api",
                                                publisher="GOV.UK", found_via=via, api=r,
                                                reuse_checked="n/a (GOV.UK API)") for r in res])
                    got += len(res)
                status.append({"source": src["id"], "status": f"ok, {got} results over {len(queries)} queries"})
            else:
                raise ValueError(f"unknown source type {src['type']}")
        except Exception as e:
            log.error("source %s failed: %s", src["id"], e)
            status.append({"source": src["id"], "status": f"FAILED: {e}"})
    merged, seen = [], set()

    def add(c):
        k = normalise_url(c.url)
        if k not in seen:
            seen.add(k)
            merged.append(c)

    for c in curated:
        add(c)
    depth = 0
    while any(depth < len(l) for l in api_lists):
        for l in api_lists:
            if depth < len(l):
                add(l[depth])
        depth += 1
    return merged[: int(limit * 1.5) + 2]
