"""Topic summary, discovered keyword candidates, content opportunities and service-term sheet."""
from __future__ import annotations

import csv
import math
from datetime import date

from .scoring import best_date

TOPIC_COLS = ["topic", "topic_group", "audience", "jurisdictions_in_sources", "intent", "total_mentions", "pages",
              "unique_publishers", "publishers", "latest_mention", "pages_last_3_months", "authority_discussed",
              "authority_evidence", "avg_relevance", "research_priority_score", "term_origin"]
CANDIDATE_COLS = ["candidate", "total_mentions", "pages", "unique_publishers", "publishers", "latest_mention",
                  "audience_relevance_share", "authority_evidence", "support", "review_status", "example_urls"]
OPP_COLS = ["topic", "intended_audience", "jurisdictions", "why_it_stands_out", "supporting_sources",
            "suggested_format", "caveat"]
SERVICE_COLS = ["phrase", "topic_group", "audience", "jurisdiction", "mentions_in_collected_pages", "pages",
                "disc_offer_check", "note"]
PAGE_COLS = ["url", "title", "publisher", "publisher_tier", "source", "document_type", "evidence_type", "duplicate_of",
             "jurisdiction", "jurisdiction_evidence", "guidance_version", "version_evidence", "currency_flag",
             "published", "updated", "retrieved", "date_source", "recent_flag", "relevance", "relevance_evidence",
             "authority", "authority_evidence", "recency_score", "recency_evidence", "topics", "topic_groups",
             "included_in_summary", "inclusion_reason", "found_via_phrase", "found_via_group", "found_via_audience",
             "found_via_jurisdiction", "found_via_intent", "reuse_checked"]


def ds(d):
    return d.isoformat() if d else "unknown"


def page_rows(pages, by_id):
    rows = []
    for p in pages:
        topics = sorted(((by_id[t].phrase, n) for t, n in p.term_hits.items() if by_id[t].intent != "service"),
                        key=lambda x: -x[1])
        rows.append({
            "url": p.url, "title": p.title, "publisher": p.publisher, "publisher_tier": p.publisher_tier,
            "source": p.source, "document_type": p.document_type, "evidence_type": p.evidence_type,
            "duplicate_of": p.duplicate_of, "jurisdiction": p.jurisdiction,
            "jurisdiction_evidence": p.jurisdiction_evidence, "guidance_version": p.guidance_version,
            "version_evidence": p.version_evidence, "currency_flag": p.currency_flag,
            "published": ds(p.published), "updated": ds(p.updated), "retrieved": ds(p.retrieved),
            "date_source": p.date_source, "recent_flag": p.recent_flag, "relevance": p.relevance,
            "relevance_evidence": p.relevance_evidence, "authority": p.authority,
            "authority_evidence": p.authority_evidence,
            "recency_score": "unknown" if p.recency_score is None else p.recency_score,
            "recency_evidence": p.recency_evidence,
            "topics": "; ".join(f"{t} ({n})" for t, n in topics),
            "topic_groups": "; ".join(sorted({by_id[t].group_name for t in p.term_hits if by_id[t].intent != "service"})),
            "included_in_summary": "yes" if p.included else "no", "inclusion_reason": p.reason,
            "found_via_phrase": p.found_via.get("phrase", ""), "found_via_group": p.found_via.get("group", ""),
            "found_via_audience": p.found_via.get("audience", ""),
            "found_via_jurisdiction": p.found_via.get("jurisdiction", ""),
            "found_via_intent": p.found_via.get("intent", ""), "reuse_checked": p.reuse_checked})
    return rows


def _publisher_evidence(users):
    by = {}
    for p in users:
        by.setdefault(p.publisher, []).append(p)
    return "; ".join(f"{pub} ({ps[0].publisher_tier}, {len(ps)} page{'s' if len(ps) > 1 else ''}, "
                     f"best authority {max(x.authority for x in ps):.2f})" for pub, ps in list(by.items())[:4])


def _core(users, total, cfg):
    latest = max((best_date(p) for p in users if best_date(p)), default=None)
    auth = any(cfg["tiers"].get(p.publisher_tier, 0) >= 0.25 for p in users)
    return {"total_mentions": total, "pages": len(users),
            "unique_publishers": len({p.publisher for p in users}),
            "publishers": "; ".join(sorted({p.publisher for p in users})), "latest_mention": ds(latest),
            "pages_last_3_months": sum(1 for p in users if p.recent_flag == "yes"),
            "authority_discussed": "yes" if auth else "no", "authority_evidence": _publisher_evidence(users),
            "avg_relevance": round(sum(p.relevance for p in users) / len(users), 2),
            "_recency": max((p.recency_score or 0) for p in users), "_authority": max(p.authority for p in users),
            "_users": users}


def _priority(rows, cfg):
    if not rows:
        return
    w = cfg["priority_weights"]
    mt, mp = max(r["total_mentions"] for r in rows), max(r["unique_publishers"] for r in rows)
    for r in rows:
        f = math.log1p(r["total_mentions"]) / math.log1p(mt) if mt else 0
        pb = r["unique_publishers"] / mp if mp else 0
        r["research_priority_score"] = round(100 * (w["frequency"] * f + w["publishers"] * pb
                                                    + w["recency"] * r.pop("_recency") + w["authority"] * r.pop("_authority")), 1)


def topic_summary(pages, terms, cfg):
    inc = [p for p in pages if p.included]
    rows = []
    for t in terms:
        if t.intent == "service":
            continue
        users = [p for p in inc if p.term_hits.get(t.id)]
        if not users:
            continue
        r = _core(users, sum(p.term_hits[t.id] for p in users), cfg)
        js = sorted({j for p in users for j in p.jurisdictions})
        r.update({"topic": t.phrase, "topic_group": t.group_name, "audience": t.audience,
                  "jurisdictions_in_sources": "; ".join(js) or "unclear", "intent": t.intent,
                  "term_origin": "keyword bank"})
        rows.append(r)
    _priority(rows, cfg)
    rows.sort(key=lambda r: -r["research_priority_score"])
    return rows


def discovered_candidates(pages, terms, cfg):
    """Phrases not in the bank. Never added automatically: each is flagged for manual review."""
    inc = [p for p in pages if p.included]
    kc = cfg["keywords"]
    bank_sets = [s for t in terms for s in t.token_sets]
    from .bank import norm_tok
    ignore = [tuple(i.split()) for i in kc["ignore_phrases"]]
    allgrams = set()
    for p in inc:
        allgrams.update(p.ngrams)
    rows = []
    for g in allgrams:
        toks = frozenset(norm_tok(w) for w in g.split())
        if any(toks <= s for s in bank_sets):
            continue
        words = tuple(g.split())
        if any(all(w in words for w in ig) for ig in ignore):
            continue
        users = [p for p in inc if p.ngrams.get(g)]
        total = sum(p.ngrams[g] for p in users)
        share = sum(p.rel_ngrams.get(g, 0) for p in users) / total
        if share < kc["min_audience_relevance_share"]:
            continue
        support = []
        if any(p.publisher_tier == "primary_authority" for p in users):
            support.append("authoritative primary source")
        if len({p.publisher for p in users}) >= 2:
            support.append("2+ independent publishers")
        r = _core(users, total, cfg)
        r.update({"candidate": g, "audience_relevance_share": round(share, 2), "support": "; ".join(support),
                  "review_status": "review for bank" if support else "not enough support yet",
                  "example_urls": " | ".join(p.url for p in users[:2])})
        rows.append(r)
    _priority(rows, cfg)
    rows.sort(key=lambda r: (r["review_status"] != "review for bank", -r["research_priority_score"]))
    return rows[: kc["max_candidates"]]


def content_opportunities(topic_rows, cfg):
    out = []
    for r in topic_rows:
        if r["authority_discussed"] != "yes":
            continue
        top = sorted(r["_users"], key=lambda p: (p.authority, (best_date(p) or date.min).toordinal()), reverse=True)[:3]
        out.append({
            "topic": r["topic"], "intended_audience": r["audience"], "jurisdictions": r["jurisdictions_in_sources"],
            "why_it_stands_out": (f"{r['total_mentions']} mentions on {r['pages']} page(s) from {r['unique_publishers']} "
                                  f"publisher(s); latest {r['latest_mention']}; priority {r['research_priority_score']}"),
            "supporting_sources": " || ".join(f"{p.publisher}: {p.title} ({ds(best_date(p))}) {p.url}" for p in top),
            "suggested_format": f"Briefing or explainer for {r['audience']}",
            "caveat": "Mentions in collected pages are not search demand. Check against DISC's offer and validate demand first."})
        if len(out) >= cfg["opportunities"]["top_n"]:
            break
    return out


def load_offerings(path):
    try:
        with open(path, newline="", encoding="utf-8-sig") as f:
            return [r["offering"].strip() for r in csv.DictReader(f) if (r.get("offering") or "").strip()]
    except FileNotFoundError:
        return []


def service_terms(pages, terms, matcher, offerings):
    inc = [p for p in pages if p.included]
    off_sets = [(o, matcher.content_tokens(o)) for o in offerings]
    rows = []
    for t in terms:
        if t.intent != "service":
            continue
        users = [p for p in inc if p.term_hits.get(t.id)]
        if not offerings:
            check = "not checked (disc_offerings.csv is empty)"
        else:
            mine = set().union(*t.token_sets) if t.token_sets else set()
            best = max(((len(mine & s) / max(len(mine | s), 1), o) for o, s in off_sets), default=(0, ""))
            check = f"possible match: {best[1]} (confirm with DISC)" if best[0] >= 0.5 else "no matching offering listed"
        rows.append({"phrase": t.phrase, "topic_group": t.group_name, "audience": t.audience,
                     "jurisdiction": t.jurisdiction, "mentions_in_collected_pages": sum(p.term_hits[t.id] for p in users),
                     "pages": len(users), "disc_offer_check": check,
                     "note": "Search phrase only. Do not link it to a service page until DISC confirms the offer."})
    return rows
