"""Polite downloading: robots.txt, per-host delay, local cache kept between runs."""
from __future__ import annotations

import hashlib
import json
import logging
import threading
import time
from datetime import date, datetime
from pathlib import Path
from urllib.parse import urlparse
from urllib.robotparser import RobotFileParser

import requests
from bs4 import UnicodeDammit

log = logging.getLogger("agent")


class SkipPage(Exception):
    pass


def to_date(s):
    try:
        return date.fromisoformat(str(s)[:10]) if s else None
    except ValueError:
        return None


class Fetcher:
    def __init__(self, cfg: dict, pages_dir: Path, api_dir: Path):
        self.cfg, self.pages_dir, self.api_dir = cfg, pages_dir, api_dir
        self.headers = {"User-Agent": cfg["user_agent"]}
        self.lock, self.robots, self.next_ok = threading.Lock(), {}, {}

    def _throttle(self, host: str, delay: float):
        with self.lock:
            now = time.monotonic()
            start = max(now, self.next_ok.get(host, 0))
            self.next_ok[host] = start + delay
        if start > now:
            time.sleep(start - now)

    def _robots_ok(self, url: str) -> bool:
        u = urlparse(url)
        base = f"{u.scheme}://{u.netloc}"
        with self.lock:
            rp = self.robots.get(base)
        if rp is None:
            rp = RobotFileParser()
            try:
                r = requests.get(base + "/robots.txt", headers=self.headers, timeout=8)
                if r.status_code == 200:
                    rp.parse(r.text.splitlines())
                elif r.status_code in (401, 403):
                    rp.disallow_all = True
                else:
                    rp.parse([])
            except requests.RequestException:
                rp.parse([])
            with self.lock:
                self.robots[base] = rp
        return rp.can_fetch(self.headers["User-Agent"], url)

    def _fresh(self, path: Path) -> bool:
        return path.exists() and time.time() - path.stat().st_mtime < self.cfg["fetch"]["cache_days"] * 86400

    def page(self, url: str):
        """Return (html, meta, from_cache). Raises SkipPage or requests errors."""
        fc = self.cfg["fetch"]
        key = hashlib.sha1(url.encode()).hexdigest()[:16]
        hp, mp = self.pages_dir / f"{key}.html", self.pages_dir / f"{key}.json"
        if self._fresh(mp) and hp.exists():
            return hp.read_text("utf-8", errors="replace"), json.loads(mp.read_text("utf-8")), True
        if not self._robots_ok(url):
            raise SkipPage("blocked by robots.txt")
        self._throttle(urlparse(url).netloc, fc["per_host_delay_seconds"])
        r = requests.get(url, headers=self.headers, timeout=fc["timeout_seconds"], stream=True)
        r.raise_for_status()
        ctype = r.headers.get("Content-Type", "")
        if "html" not in ctype.lower():
            raise SkipPage(f"not HTML ({ctype or 'unknown type'})")
        raw, limit = b"", fc["max_page_mb"] * 1024 * 1024
        for chunk in r.iter_content(65536):
            raw += chunk
            if len(raw) > limit:
                break
        html = UnicodeDammit(raw).unicode_markup or ""
        meta = {"url": url, "final_url": r.url, "fetched_at": datetime.now().isoformat(timespec="seconds"),
                "status": r.status_code}
        hp.write_text(html, "utf-8")
        mp.write_text(json.dumps(meta), "utf-8")
        return html, meta, False

    def json(self, url: str, delay: float):
        key = hashlib.sha1(url.encode()).hexdigest()[:16]
        cp = self.api_dir / f"{key}.json"
        if self._fresh(cp):
            return json.loads(cp.read_text("utf-8"))
        self._throttle(urlparse(url).netloc, delay)
        r = requests.get(url, headers=self.headers, timeout=self.cfg["fetch"]["timeout_seconds"])
        r.raise_for_status()
        data = r.json()
        cp.write_text(json.dumps(data), "utf-8")
        return data

    def govuk_meta(self, url: str) -> dict:
        """Dates, withdrawal status and organisations from the GOV.UK content API. {} on any failure."""
        u = urlparse(url)
        if not u.netloc.endswith("gov.uk"):
            return {}
        try:
            d = self.json(f"{u.scheme}://{u.netloc}/api/content{u.path}", 0.5)
        except Exception as e:
            log.warning("GOV.UK content API unavailable for %s: %s", url, e)
            return {}
        orgs = [{"slug": (o.get("base_path") or "").rstrip("/").split("/")[-1], "title": o.get("title", "")}
                for o in ((d.get("links") or {}).get("organisations") or []) if isinstance(o, dict)]
        return {"published": to_date(d.get("first_published_at")), "updated": to_date(d.get("public_updated_at")),
                "withdrawn": bool(d.get("withdrawn_notice")), "document_type": d.get("document_type", ""),
                "organisations": orgs}
