"""Run orchestration: sources -> download -> read -> score -> aggregate -> write."""
from __future__ import annotations

import logging
import sys
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path

import yaml

from . import __version__
from .aggregate import (CANDIDATE_COLS, OPP_COLS, PAGE_COLS, SERVICE_COLS, TOPIC_COLS, content_opportunities,
                        discovered_candidates, load_offerings, page_rows, service_terms, topic_summary)
from .analyse import analyse_page
from .bank import Matcher, Normaliser, Query, expand_queries, load_bank, select_terms
from .fetch import Fetcher, SkipPage
from .output import write_tables
from .scoring import finalise, score_relevance
from .sources import collect_candidates

MAX_CONCURRENCY = 5  # fixed upper limit on simultaneous downloads, whatever the user asks for
log = logging.getLogger("agent")


@dataclass
class Options:
    sites: int = 20                 # user-set limit on pages read
    workers: int = 3
    groups: list | None = None      # keyword-bank groups to use, e.g. [1, 3, 6]
    max_terms: int = 12             # bank terms searched per run
    expand: str = ""                # "", audiences, platforms or jurisdictions
    sources: list | None = None     # restrict to these source ids
    fmt: str = "csv"
    data_dir: str = "agent_data"
    config: str = str(Path(__file__).resolve().parent.parent / "config.yaml")


class ErrorCollector(logging.Handler):
    def __init__(self):
        super().__init__(level=logging.WARNING)
        self.lines = []

    def emit(self, record):
        self.lines.append(self.format(record))


def load_config(path: str) -> dict:
    cfg = yaml.safe_load(Path(path).read_text("utf-8"))
    cfg["_root"] = Path(path).resolve().parent
    return cfg


def _path(cfg, key):
    p = Path(cfg[key])
    return p if p.is_absolute() else cfg["_root"] / p


def run(opts: Options, cfg: dict, dirs: dict, state: dict):
    bank = load_bank(_path(cfg, "bank_file"))
    matcher = Matcher(bank, Normaliser(cfg["spelling_map"]))
    selected = select_terms(bank, opts.groups, max_terms=opts.max_terms)
    queries = [Query(t.query_text, t, t.audience, t.jurisdiction) for t in selected]
    queries += expand_queries(selected, cfg["expansions"], opts.expand)
    state.update(bank=bank, matcher=matcher, queries=queries)
    workers = max(1, min(opts.workers, MAX_CONCURRENCY))
    log.info("bank=%d terms, %d queries this run, sites<=%d, workers=%d", len(bank), len(queries), opts.sites, workers)

    cands = collect_candidates(cfg, queries, opts.sources, opts.sites, cfg["_root"], state["source_status"])
    state["candidates"] = len(cands)
    if not cands:
        raise RuntimeError("no candidate pages found from any source (see source status in the log)")

    fetcher = Fetcher(cfg, dirs["pages"], dirs["api"])
    pending, pages = list(cands), state["pages"]
    ex = ThreadPoolExecutor(max_workers=workers)

    def work(c):
        html, meta, cached = fetcher.page(c.url)
        api = fetcher.govuk_meta(c.url)
        page = analyse_page(c, html, meta, api, matcher, cfg)
        score_relevance(page, matcher.by_id, cfg)
        return page, cached

    try:
        while len(pages) < opts.sites and pending:
            n = opts.sites - len(pages)
            batch, pending = pending[:n], pending[n:]
            futs = {ex.submit(work, c): c for c in batch}
            for fut in as_completed(futs):
                c = futs[fut]
                try:
                    page, cached = fut.result()
                    pages.append(page)
                    log.info("%s %-70.70s relevance=%.2f", "cache" if cached else "fetch", c.url, page.relevance)
                except SkipPage as e:
                    log.warning("skipped %s: %s", c.url, e)
                except Exception as e:
                    log.warning("failed %s: %s: %s", c.url, type(e).__name__, e)
    except KeyboardInterrupt:
        ex.shutdown(wait=False, cancel_futures=True)
        raise
    ex.shutdown(wait=True)
    if not pages:
        raise RuntimeError("no pages could be downloaded and read")


def finish(opts, cfg, dirs, stamp, state, status):
    pages = state["pages"]
    if not pages:
        return []
    bank, matcher = state["bank"], state["matcher"]
    finalise(pages, cfg, date.today())
    topics = topic_summary(pages, bank, cfg)
    info = [
        ("status", status), ("run_time", stamp), ("agent_version", __version__),
        ("pages_requested_limit", opts.sites), ("pages_read", len(pages)),
        ("pages_included", sum(p.included for p in pages)),
        ("pages_repeated_or_syndicated", sum(p.evidence_type != "original" for p in pages)),
        ("concurrency_used", max(1, min(opts.workers, MAX_CONCURRENCY))),
        ("keyword_groups", opts.groups or "all"), ("terms_per_run_limit", opts.max_terms),
        ("expansion_mode", opts.expand or "none"), ("config_file", opts.config),
        ("note", "Mentions in collected pages are not search demand. Scores prioritise research, not rankings."),
    ] + [(f"source:{s['source']}", s["status"]) for s in state["source_status"]] \
      + [(f"query {i + 1}", f"{q.text} [{q.term.group_name}; {q.audience}; {q.jurisdiction}; {q.term.intent}"
          f"{'; ' + q.expansion if q.expansion else ''}]") for i, q in enumerate(state.get("queries", []))]
    tables = {
        "topic_summary": (TOPIC_COLS, topics),
        "keyword_candidates_for_review": (CANDIDATE_COLS, discovered_candidates(pages, bank, cfg)),
        "page_evidence": (PAGE_COLS, page_rows(pages, matcher.by_id)),
        "content_opportunities": (OPP_COLS, content_opportunities(topics, cfg)),
        "service_search_terms": (SERVICE_COLS, service_terms(pages, bank, matcher, load_offerings(_path(cfg, "disc_offerings_file")))),
        "run_info": (["setting", "value"], [{"setting": k, "value": str(v)} for k, v in info]),
    }
    paths = write_tables(tables, opts.fmt, dirs["output"], stamp)
    for p in paths:
        log.info("wrote %s", p)
    return paths


def execute(opts: Options) -> int:
    root = Path(opts.data_dir)
    dirs = {k: root / k for k in ("pages", "api", "logs", "output")}
    for d in dirs.values():
        d.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(message)s", "%H:%M:%S")
    errors, handlers = ErrorCollector(), []
    for h in (logging.FileHandler(dirs["logs"] / f"run_{stamp}.log", encoding="utf-8"), logging.StreamHandler(sys.stdout), errors):
        h.setFormatter(fmt)
        log.addHandler(h)
        handlers.append(h)
    log.setLevel(logging.INFO)
    state, status, cfg = {"pages": [], "candidates": 0, "source_status": []}, "completed", None
    try:
        cfg = load_config(opts.config)
        if "ADD-CONTACT-EMAIL" in cfg["user_agent"]:
            log.warning("user_agent in config.yaml still has the contact placeholder. Add a real contact email")
        run(opts, cfg, dirs, state)
    except KeyboardInterrupt:
        status = "interrupted"
        log.error("run interrupted by user")
    except Exception as e:
        status = "failed"
        log.error("run failed: %s: %s\n%s", type(e).__name__, e, traceback.format_exc())
    finally:
        try:
            if cfg and state.get("matcher"):
                finish(opts, cfg, dirs, stamp, state, status)
        except Exception as e:
            status = "failed"
            log.error("could not write output: %s\n%s", e, traceback.format_exc())
        if status != "completed" or errors.lines:
            rep = dirs["logs"] / f"report_{stamp}.txt"
            rep.write_text(f"Run {stamp}: {status.upper()}\nPages read: {len(state['pages'])}\n"
                           f"Warnings and errors: {len(errors.lines)}\n\n" + "\n".join(errors.lines), "utf-8")
            log.info("log report written to %s", rep)
        log.info("status: %s", status)
        for h in handlers:
            log.removeHandler(h)
            h.close()
    return 0 if status == "completed" else 1
