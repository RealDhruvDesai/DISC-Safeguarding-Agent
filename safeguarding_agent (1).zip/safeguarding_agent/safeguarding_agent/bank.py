"""Keyword bank: loading, spelling normalisation, per-run term selection and text matching."""
from __future__ import annotations

import csv
import re
from collections import Counter
from dataclasses import dataclass, field

STOP = set(
    """a about above after again against all also am an and any are aren as at be because been before
    being below between both but by can cannot could did do does doing down during each few for from
    further had has have having he her here hers him his how i if in into is it its just me more most
    my no nor not now of off on once only or other our out over own same she should so some such than
    that the their theirs them then there these they this those through to too under until up us very
    was we were what when where which while who whom why will with would you your yours cookie cookies
    privacy policy terms conditions menu login subscribe newsletter copyright reserved rights share
    website page pages site may might many much one two three however within without per via etc""".split()
)
WORD = re.compile(r"[a-z0-9]+")
CHUNK = re.compile(r"[.!?\n;:|\u2022()\[\]\"\u201c\u201d]+")


def norm_tok(t: str) -> str:
    return t[:-1] if len(t) > 4 and t.endswith("s") and not t.endswith("ss") else t


class Normaliser:
    """Lower-cases, applies the spelling map, and turns hyphens/slashes into spaces."""

    def __init__(self, spelling: dict | None = None):
        self.pats = [(re.compile(r"\b" + re.escape(k.lower()) + r"\b"), v.lower()) for k, v in (spelling or {}).items()]

    def __call__(self, text: str) -> str:
        t = text.lower().replace("\u2019", "'")
        for pat, rep in self.pats:
            t = pat.sub(rep, t)
        t = t.replace("'", "")
        return re.sub(r"[-/\u2013\u2014_]", " ", t)


@dataclass
class Term:
    id: str
    phrase: str
    group: int
    group_name: str
    audience: str
    jurisdiction: str
    intent: str          # research | service | question
    priority: int
    platform: str
    variants: list       # phrase first, then spelling/wording variants
    token_sets: list = field(default_factory=list, repr=False)

    @property
    def query_text(self) -> str:
        # questions make poor search queries, so use their topical core (first extra variant)
        return self.variants[1] if self.intent == "question" and len(self.variants) > 1 else self.phrase


@dataclass
class Query:
    text: str
    term: Term
    audience: str
    jurisdiction: str
    expansion: str = ""


def load_bank(path) -> list:
    terms = []
    with open(path, newline="", encoding="utf-8-sig") as f:
        for i, row in enumerate(csv.DictReader(f), 1):
            phrase = (row.get("phrase") or "").strip()
            if not phrase:
                continue
            variants = [v.strip() for v in (row.get("variants") or "").split("|") if v.strip()]
            terms.append(Term(
                id=f"T{i:03d}", phrase=phrase, group=int(row["group"]), group_name=row["group_name"].strip(),
                audience=(row.get("audience") or "safeguarding professionals").strip(),
                jurisdiction=(row.get("jurisdiction") or "unspecified").strip(),
                intent=row["intent"].strip().lower(), priority=int(row.get("priority") or 2),
                platform=(row.get("platform") or "").strip(), variants=[phrase] + variants))
    return terms


def select_terms(terms, groups=None, intents=("research", "question"), max_terms=12) -> list:
    """Pick a manageable set: best priority first, rotating through topic groups for spread."""
    pool = [t for t in terms if t.intent in intents and (not groups or t.group in groups)]
    chosen: list = []
    for prio in sorted({t.priority for t in pool}):
        buckets: dict = {}
        for t in pool:
            if t.priority == prio:
                buckets.setdefault(t.group, []).append(t)
        queues = [buckets[g] for g in sorted(buckets)]
        while queues and len(chosen) < max_terms:
            for q in list(queues):
                if len(chosen) >= max_terms:
                    break
                chosen.append(q.pop(0))
                if not q:
                    queues.remove(q)
        if len(chosen) >= max_terms:
            break
    return chosen


def expand_queries(selected, exp_cfg: dict, mode: str) -> list:
    """Capped, rotating expansions (audience, platform or jurisdiction). Never every combination."""
    cap, out = exp_cfg["max_queries"], []
    if mode == "audiences":
        mods = list(exp_cfg["audiences"].items())
        for i, t in enumerate([t for t in selected if t.group in (1, 2, 3, 6)][:cap]):
            label, mod = mods[i % len(mods)]
            out.append(Query(f"{t.query_text} {mod}", t, label, t.jurisdiction, f"audience: {label}"))
    elif mode == "platforms":
        plats = exp_cfg["platforms"]
        for i, t in enumerate([t for t in selected if t.group == 4 and not t.platform][:cap]):
            out.append(Query(f"{t.query_text} {plats[i % len(plats)]}", t, t.audience, t.jurisdiction, f"platform: {plats[i % len(plats)]}"))
    elif mode == "jurisdictions":
        js = exp_cfg["jurisdictions"]
        for i, t in enumerate([t for t in selected if t.jurisdiction in ("unspecified", "UK")][:cap]):
            out.append(Query(f"{t.query_text} {js[i % len(js)]}", t, t.audience, js[i % len(js)], f"jurisdiction: {js[i % len(js)]}"))
    elif mode:
        raise ValueError(f"unknown expansion mode: {mode}")
    return out


class Matcher:
    """Matches bank terms against text. A term hits a sentence/line when all content words of
    any of its variants appear in it."""

    def __init__(self, terms, normaliser: Normaliser):
        self.terms, self.norm = terms, normaliser
        self.by_id = {t.id: t for t in terms}
        for t in terms:
            t.token_sets = [s for s in (self.content_tokens(v) for v in t.variants) if s]

    def content_tokens(self, s: str) -> frozenset:
        return frozenset(norm_tok(w) for w in WORD.findall(self.norm(s)) if w not in STOP and len(w) >= 2)

    def hits(self, text: str) -> Counter:
        return self.scan(text)[0]

    def scan(self, text: str):
        """Return (term hits, 2-3 word phrase counts, phrase counts inside sentences that hit a research term)."""
        hits, ngrams, rel = Counter(), Counter(), Counter()
        for chunk in CHUNK.split(self.norm(text)):
            if not chunk.strip():
                continue
            raw = WORD.findall(chunk)
            toks = {norm_tok(w) for w in raw if w not in STOP and len(w) >= 2}
            chunk_hit = False
            for t in self.terms:
                if any(s <= toks for s in t.token_sets):
                    hits[t.id] += 1
                    chunk_hit = chunk_hit or t.intent != "service"
            for n in (2, 3):
                for i in range(len(raw) - n + 1):
                    g = raw[i:i + n]
                    if any(w in STOP or len(w) < 3 for w in g):
                        continue
                    key = " ".join(g)
                    ngrams[key] += 1
                    if chunk_hit:
                        rel[key] += 1
        return hits, ngrams, rel
