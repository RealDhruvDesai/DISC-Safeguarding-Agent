"""Writes the result tables as CSV files (default) or one .xlsx workbook."""
from __future__ import annotations

import csv
from pathlib import Path


def safe(v):
    """Stop text from the web being run as a formula when the file is opened in Excel."""
    return "'" + v if isinstance(v, str) and v[:1] in ("=", "+", "-", "@", "\t", "\r") else v


def write_tables(tables: dict, fmt: str, out_dir: Path, stamp: str) -> list:
    """tables: name -> (columns, rows). Extra row keys (internal fields) are ignored."""
    if fmt == "csv":
        paths = []
        for name, (cols, rows) in tables.items():
            path = out_dir / f"{name}_{stamp}.csv"
            with open(path, "w", newline="", encoding="utf-8-sig") as f:  # utf-8-sig opens cleanly in Excel
                wr = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
                wr.writeheader()
                wr.writerows({k: safe(v) for k, v in r.items()} for r in rows)
            paths.append(path)
        return paths
    from openpyxl import Workbook
    from openpyxl.styles import Font
    wb = Workbook()
    wb.remove(wb.active)
    for name, (cols, rows) in tables.items():
        ws = wb.create_sheet(name[:31])
        ws.append(cols)
        for r in rows:
            ws.append([safe(r.get(c, "")) for c in cols])
        for cell in ws[1]:
            cell.font = Font(name="Arial", bold=True)
        ws.freeze_panes = "A2"
        for i, c in enumerate(cols, 1):
            width = max([len(str(c))] + [len(str(r.get(c, ""))) for r in rows[:100]])
            ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = min(max(width + 2, 10), 60)
    path = out_dir / f"results_{stamp}.xlsx"
    wb.save(path)
    return [path]
