from safeguarding_agent.bank import Matcher, Normaliser, expand_queries, load_bank, select_terms
from safeguarding_agent.analyse import detect_jurisdiction
from safeguarding_agent.pipeline import Options, execute, load_config
from safeguarding_agent.sources import normalise_url, parse_govuk_results

from conftest import ROOT, read_csv


def run(tmp_path, make_config, rows, **kw):
    data = tmp_path / "data"
    code = execute(Options(sites=10, workers=2, data_dir=str(data), config=make_config(rows), **kw))
    return code, data


def pages_by_url(data):
    return {r["url"].rsplit("/", 1)[-1]: r for r in read_csv(data / "output", "page_evidence")}


def test_irrelevant_page_is_excluded(site, tmp_path, make_config):
    code, data = run(tmp_path, make_config, [[f"{site}/a.html", "Test Regulator", "yes", ""], [f"{site}/garden.html", "Test Regulator", "yes", ""]])
    pages = pages_by_url(data)
    assert pages["garden.html"]["included_in_summary"] == "no"
    assert "relevance" in pages["garden.html"]["inclusion_reason"]
    assert pages["a.html"]["included_in_summary"] == "yes"


def test_duplicates_are_flagged_and_not_counted_as_independent(site, tmp_path, make_config):
    rows = [[f"{site}/a.html", "Test Regulator", "yes", ""], [f"{site}/dup.html", "Test Charity", "yes", ""]]
    code, data = run(tmp_path, make_config, rows)
    pages = pages_by_url(data)
    assert pages["a.html"]["evidence_type"] == "original"
    assert pages["dup.html"]["evidence_type"] == "repeated/syndicated"
    assert pages["dup.html"]["duplicate_of"].endswith("a.html")
    topics = {r["topic"]: r for r in read_csv(data / "output", "topic_summary")}
    assert topics["Online grooming"]["unique_publishers"] == "1"


def test_missing_dates_stay_unknown_and_page_is_kept(site, tmp_path, make_config):
    code, data = run(tmp_path, make_config, [[f"{site}/cyber.html", "Test Regulator", "yes", ""]])
    p = pages_by_url(data)["cyber.html"]
    assert (p["published"], p["updated"], p["recent_flag"], p["recency_score"]) == ("unknown", "unknown", "unknown", "unknown")
    assert p["included_in_summary"] == "yes"


def test_failed_downloads_are_logged_and_run_continues(site, tmp_path, make_config):
    rows = [[f"{site}/a.html", "Test Regulator", "yes", ""], [f"{site}/missing.html", "Test Regulator", "yes", ""],
            ["http://127.0.0.1:9/nothing.html", "Test Regulator", "yes", ""]]
    code, data = run(tmp_path, make_config, rows)
    assert code == 0 and "a.html" in pages_by_url(data)
    report = next((data / "logs").glob("report_*.txt")).read_text()
    assert "missing.html" in report and "nothing.html" in report


def test_no_candidates_fails_with_report(tmp_path, make_config):
    code, data = run(tmp_path, make_config, [])
    assert code == 1
    assert "FAILED" in next((data / "logs").glob("report_*.txt")).read_text()


def test_recent_flag_and_dates(site, tmp_path, make_config):
    code, data = run(tmp_path, make_config, [[f"{site}/a.html", "Test Regulator", "yes", ""]])
    p = pages_by_url(data)["a.html"]
    assert p["published"] == "2026-01-10" and p["updated"] == "2026-10-01" and p["retrieved"] != "unknown"


def test_service_terms_kept_out_of_topic_summary(site, tmp_path, make_config):
    code, data = run(tmp_path, make_config, [[f"{site}/a.html", "Test Regulator", "yes", ""]])
    topics = {r["intent"] for r in read_csv(data / "output", "topic_summary")}
    assert "service" not in topics
    assert read_csv(data / "output", "service_search_terms")  # separate output exists


def test_spelling_variants_merge():
    bank = load_bank(ROOT / "keyword_bank.csv")
    cfg = load_config(str(ROOT / "config.yaml"))
    m = Matcher(bank, Normaliser(cfg["spelling_map"]))
    online_safety = next(t for t in bank if t.phrase == "Online safety")
    sext = next(t for t in bank if t.phrase.startswith("Sexual extortion"))
    assert m.hits("The e-safety lead updated the policy.")[online_safety.id] == 1
    assert m.hits("Sexual extortion of teenagers is rising.")[sext.id] == 1


def test_selection_is_capped_and_spread():
    bank = load_bank(ROOT / "keyword_bank.csv")
    chosen = select_terms(bank, max_terms=12)
    assert len(chosen) == 12 and len({t.group for t in chosen}) >= 4
    assert all(t.intent != "service" for t in chosen)
    cfg = load_config(str(ROOT / "config.yaml"))
    assert len(expand_queries(chosen, cfg["expansions"], "audiences")) <= cfg["expansions"]["max_queries"]


def test_jurisdiction_detection():
    rules = load_config(str(ROOT / "config.yaml"))["jurisdiction_rules"]
    j, ev = detect_jurisdiction("Keeping Learners Safe", "Welsh Government guidance for schools in Wales.", rules, None)
    assert j == ["Wales"]
    assert detect_jurisdiction("Plain page", "nothing here", rules, None)[0] == []


def test_govuk_parser_and_url_normalising():
    data = {"results": [
        {"title": "KCSIE", "link": "/government/publications/keeping-children-safe-in-education--2", "format": "guidance",
         "public_timestamp": "2025-09-01T10:00:00.000+01:00", "organisations": [{"slug": "department-for-education", "title": "Department for Education"}]},
        {"title": "Dept page", "link": "/government/organisations/department-for-education", "format": "organisation"},
        {"title": "no link"}]}
    out = parse_govuk_results(data, "https://www.gov.uk", ["organisation"])
    assert len(out) == 1 and out[0]["url"].startswith("https://www.gov.uk/government/publications")
    assert normalise_url("https://www.Example.com/a/?utm_source=x#frag") == normalise_url("https://example.com/a")


def test_titles_cannot_become_spreadsheet_formulas(tmp_path):
    from safeguarding_agent.output import write_tables
    p = write_tables({"t": (["a"], [{"a": "=HYPERLINK(1)"}, {"a": "+1"}, {"a": "ok"}])}, "csv", tmp_path, "x")[0]
    lines = p.read_text(encoding="utf-8-sig").splitlines()
    assert lines[1].startswith("'=") and lines[2].startswith("'+") and lines[3] == "ok"


def test_second_run_reuses_local_pages(site, tmp_path, make_config):
    rows = [[f"{site}/a.html", "Test Regulator", "yes", ""]]
    cfgp = make_config(rows)
    data = tmp_path / "data"
    for _ in range(2):
        assert execute(Options(sites=5, data_dir=str(data), config=cfgp)) == 0
    logs = sorted((data / "logs").glob("run_*.log"))
    assert "fetch http" in logs[0].read_text() and "cache http" in logs[-1].read_text()
    assert len(list((data / "pages").glob("*.html"))) == 1


def test_xlsx_output_has_all_sheets(site, tmp_path, make_config):
    from openpyxl import load_workbook
    data = tmp_path / "data"
    assert execute(Options(sites=5, data_dir=str(data), config=make_config([[f"{site}/a.html", "Test Regulator", "yes", ""]]), fmt="xlsx")) == 0
    names = load_workbook(next((data / "output").glob("results_*.xlsx"))).sheetnames
    assert {"topic_summary", "page_evidence", "service_search_terms", "content_opportunities", "run_info"} <= set(names)
