import csv
import functools
import http.server
import socketserver
import threading
from pathlib import Path

import pytest
import yaml

ROOT = Path(__file__).resolve().parent.parent


def html_page(title, body, published=None, updated=None, author=None):
    meta = ""
    if author:
        meta += f'<meta name="author" content="{author}">'
    if published:
        meta += f'<meta property="article:published_time" content="{published}">'
    if updated:
        meta += f'<meta property="article:modified_time" content="{updated}">'
    return (f"<html><head><title>{title}</title>{meta}</head><body><nav><a href='/'>home</a></nav>"
            f"<main><article><h1>{title}</h1><p>{body}</p></article></main></body></html>")


GROOMING = ("Online grooming happens when an adult builds trust with a child through a game or app. "
            "Designated safeguarding leads should record and escalate online safeguarding concerns quickly. "
            "Staff training on online grooming and sextortion helps pupils report what has happened to them. "
            "Schools in England follow Keeping Children Safe in Education when handling these concerns. ") * 3
CYBER = ("Cyberbullying can continue outside school hours through messaging apps and group chats. "
         "A clear online safety policy explains how pupils report cyberbullying and how staff respond. "
         "Governors in England should check that filtering and monitoring standards are met in every school. "
         "Youth workers also need to recognise online harassment and know where to refer concerns. ") * 3
GARDEN = ("Tomatoes need warm soil and regular watering through the summer months. Prune the side shoots weekly "
          "and feed the plants every fortnight with a high potash fertiliser. Slugs and aphids can damage young "
          "plants, so check the leaves often. You can read more online about growing vegetables. ") * 4


@pytest.fixture(scope="session")
def site(tmp_path_factory):
    d = tmp_path_factory.mktemp("site")
    pages = {
        "a.html": html_page("Online grooming guidance 2026", GROOMING, "2026-01-10", "2026-10-01", "Test Author"),
        "dup.html": html_page("Online grooming guidance syndicated", GROOMING, "2026-02-01"),
        "cyber.html": html_page("Cyberbullying and online safety policy", CYBER),            # no dates at all
        "garden.html": html_page("Growing tomatoes", GARDEN, "2026-09-01"),                  # irrelevant
    }
    for name, content in pages.items():
        (d / name).write_text(content, "utf-8")
    handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(d))
    handler.log_message = lambda *a, **k: None
    srv = socketserver.ThreadingTCPServer(("127.0.0.1", 0), handler)
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{srv.server_address[1]}"
    srv.shutdown()


@pytest.fixture
def make_config(tmp_path):
    """Config with one url_list source pointing at the test site."""
    def build(rows):
        urls = tmp_path / "urls.csv"
        with open(urls, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["url", "publisher", "reuse_checked", "note"])
            w.writerows(rows)
        cfg = yaml.safe_load((ROOT / "config.yaml").read_text())
        cfg["bank_file"] = str(ROOT / "keyword_bank.csv")
        cfg["disc_offerings_file"] = str(tmp_path / "none.csv")
        cfg["sources"] = [{"id": "test", "type": "url_list", "enabled": True, "file": str(urls)}]
        cfg["publishers"].update({
            "Test Regulator": {"tier": "primary_authority", "remit_groups": [1, 2, 3, 4, 5, 6, 8]},
            "Test Charity": {"tier": "specialist_organisation", "remit_groups": [1, 2, 3, 4, 5, 6, 8]}})
        cfg["fetch"]["per_host_delay_seconds"] = 0.0
        p = tmp_path / "config.yaml"
        p.write_text(yaml.safe_dump(cfg))
        return str(p)
    return build


def read_csv(directory, prefix):
    files = sorted(Path(directory).glob(f"{prefix}_*.csv"))
    with open(files[-1], newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))
